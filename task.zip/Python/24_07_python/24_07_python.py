# 1
x = float(input("enter a number:"))

if x > 0 :
    print("positive number")
elif x == 0:
    print("neutral number")
else:
    print("negative number")

# 2
light = input("enter the light color:")

if light == "green":
    print("Good to Go")
elif light == "yellow":
    print("Please Wait")
elif light == "red":
    print("Stop")
else:
    print("Invalid Traffic Light")

# 3
a = float(input("enter the first number:"))
b = float(input("enter the second number:"))

if a < b:
    print(a, "is the largest number")
elif a == b:
    print(a, "and", b, "are equal")
else:
    print(b, "is the smallest number")

# 4
year = int(input("enter the year:"))

if year % 4 == 0:
    print(year, "is a leap year")
else:
    print(year, "is not a leap year")
