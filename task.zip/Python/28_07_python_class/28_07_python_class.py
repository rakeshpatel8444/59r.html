# s = ["python","html","css","js","java","c#","rust"]
# for i in range(len(s)):
#     print(i+1, s[i])
# for i in s:
#     print(i)

# n = int(input("enter the table number:"))
# # for i in range(1,11):
# #     print(n,"x",i,"=",n*i)
# for i in range(1,11):
#     print(f'{n}X{i}={n*i}') # updated version/ method

list1=[101,20,38,55,78,1] 
for i in list1:
    if i % 2 ==0:
        print(i)
