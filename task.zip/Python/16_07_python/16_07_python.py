# 1.	Add an integer and float. What is the result’s type?
int1 = 21
float1 = 25.34
print(type(int1 + float1))
# 2.	Create a string and access its:
str1 = "HELLO 10KCODERS"
# a.	First character
print(str1[0])
# b.	Last character
print(str1[-1])
# c.	A substring from index 2 to 5
print(str1[2:5])
# 3.	Concatenate two strings and print the result.
x = "HELLO"
y = "10KCODERS"
print(x + " " + y)
# 4.	Define list. What are the difference between List and Tuple.
# A "list" in Python is an ordered, mutable collection of items enclosed in square brackets [ ], whereas a "tuple" is an ordered, immutable collection of items enclosed in parentheses ( ). Lists can be modified (add, remove, update elements), while tuples cannot be changed after creation. Lists use more memory and are slower compared to tuples, which are faster and take less memory. Lists have many methods like append() and remove(), while tuples have only count() and index().
# 5.	Write a programme to print a list in reverse order.
list1 = [1, 2, 3, 4, 5, 6, 7]
print(list1[::-1])
# 6.	Create a tuple of 4 elements. Print the first and last element.
tuple1 = (3,5,6,2,7,9)
print(tuple1[0])
print(tuple1[-1])
# 7.	Try changing a value in a tuple. What happens?
tuple1[0] = 1
print(tuple1)
8.	Create a dictionary of 3 students with their marks. Print the dictionary.
dict1 = {
    "sai" : 64,
    "venu" : 77,
    "chendu" : 93,
}
print(dict1)
# 9.	Access the marks of one student using their name.
print(dict1["venu"])
# 10.	Update the marks of an existing student.
dict1["sai"] = 83
print(dict1)
# 11.	Can I access a key using a value in a dictionary.
# NO, it is not possible to access the key using value because value is mutable.
print(dict1[93])
12.	 Can I have duplicate values and keys in a dictionary? What happens if I wanted try to duplicate key in a dictionary? 
No. A Python dictionary cannot have duplicate keys. If you try to add a duplicate key, the last assigned value will overwrite the previous value for that key.
my_dict = {
    "name": "Alice",
    "name": "Bob"   # Duplicate key
}

print(my_dict)  # Output: {'name': 'Bob'}
# Yes. Values in a dictionary can be duplicated, only keys must be unique.
my_dict = {
    "a": 10,
    "b": 10,
    "c": 20
}

print(my_dict)  # Output: {'a': 10, 'b': 10, 'c': 20}
# 13.	Print all multiples of 17 using range. Numbers should start from -34 and end below 400.
print(list(range(-34,400,17)))
