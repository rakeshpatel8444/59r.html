x = 2 + 8j
y = 8 + 3j

print(x + y)
print(x - y)
print(x * y)
print(x / y)
print(x ** y)
# Errors
print(x % y)
print(x // y)
