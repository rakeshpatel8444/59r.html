# Python Basics: Arithmetic Operations & Variable Assignment

# 1. What are variables and why are they called variables? Assign two numbers to variables `a` and `b`, and print their sum.

a = 56
b = 32
sum = a + b
print(sum)

# 2. Write a Python program to subtract two numbers and print the result.

a = 73
b = 59
diff = a - b
print(diff)

# 3. Multiply two variables and store the result in a third variable. Print all three.

a = 99
b = 11
c = a * b
print(a)
print(b)
print(c)

# 4. Divide 10 by 3 and print the result with and without decimals.

print("with decimals:", 10/3)
print("without decimals:", 10//3)

# 5. Use floor division `//` to divide 17 by 4. Print the output.

s = 17 // 4
print(s)

# 6. Use the modulo operator `%` to check the remainder when 25 is divided by 6.

a = 25
b = 6
rem = 25 % 6
print("Remainder:", rem)

# 7. Calculate and print the square of a number stored in a variable.

a = 25
sq = a * a
print(sq)

# 8. Assign values to three variables `x`, `y`, `z` and compute the average.

x = 21
y = 45
z = 27
aveg = (x + y +z)/3
print("average:", aveg)

# 9. Take a number and find its cube using the `**` operator.

x = 6
cube = x ** 3
print("cube:", cube)

# 10. Create two variables `length` and `width`. Calculate and print area of a rectangle.

l = 20
w = 10
area = l * w
print("area of rectangle:", area)

# 11. Assign a variable `total_marks = 450` and `obtained_marks = 375`. Find percentage.

total_marks = 450
obtained_marks = 375
percentage = (obtained_marks / total_marks ) *10
print("percentage:", percentage)

# 12. Write a Python statement that calculates `(a + b) * c` for some values of a, b, and c.

a = 5
b = 7
c = 4
x = (a + b) * c
print(x)

# 13. Draw and show how reassignment changes variable reference to a memory block.

a = 10
print(a)
print("a's id", id(a))
#  Variable a is assigned to the value 10
a = 20
print(a)
print("a's id", id(a))
#  Now a is reassigned to 20