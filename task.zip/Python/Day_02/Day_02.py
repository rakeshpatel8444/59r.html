# Python String Indexing and Slicing Practice

# 1.	What is a string in Python?
# ans) A string in Python is a sequence of characters enclosed in quotes.

# 2.	What is indexing in a string?
# ans) Indexing refers to accessing individual characters in a string using position numbers.

# 3.	Given text = 'hello', what is text[0]? 
text = "hello"
print(text[0])

# a.	What will be the output of text[4]?
print(text[4]) 

# b.	What does text[-1] give?
print(text[-1])
# 4.	If name = 'Ajay', what is the value of name[0] + name[3]? 
name = "Ajay"
x = name[0] + name[3]
print(x)
# a.	What happens if you try name[10]?
# print(name[10])
# 5.	Given s = 'Python', what is s[0:2]? 
s = "Python"
print(s[0:2])
# a.	What does s[5:1] return?
print(s[5:1])
# 6.	Predict the output for string s =  'Python' . If the code is print(s[2: -1 :2])
s = "Python"
print(s[2: -1: 2])
# 7.	Write code to print the last 3 letters of 'elephant'.
e = "elephant"
print(e[-3:])
# 8.	How to get only the middle 3 letters from 'Science'?
p = "Science"
print(p[2:5])
# 9.	What is the difference between s[2:5] and s[2:5:1]?
print(s[2:5])    # Python uses the default step of 1.
print(s[2:5:1])  # s[start : stop : step]; you're specifying the step as 1 directly.



