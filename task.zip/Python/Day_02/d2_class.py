# str1 = 'Python course'
# str2 = 3
# print(str1 * str2)

# print(len(str1))
# str1 = 'Em antivi Em antivi.....'
# str2 = 'Python123'
# print(str2[len(str2) - 1]) #
# print(str2[len(str2) - 2])
# print(str2[len(str2) - 3])
# print(str2[-1])

# print(str2[-len(str2)])


#Slicing
str1 = 'Em antivi Em antivi.....'
# print(str1[70: 100])
# print(str1[5: 7])
# print(str1[5: 6])
# print(str1[5: 5])

# print(str1[5: 7])
# print(str1[7: 5: -1])

print(str1[7: 20])
print(str1[7: 20: 1]) #string[start : stop : step]


str1 = 'Python'
print(str1[-1: -4: -1])


print(str1[ : : -2])
