x = 10
x +=10
print(x)

x -= 5
print(x)

x *= 4
print(x)

x /= 2
print(x)

x **=2
print(x)

x //= 10
print(x)

x %= 2
print(x)
